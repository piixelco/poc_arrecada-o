"use client"

import EnhancedSupermarketDashboard from "../enhanced-supermarket-dashboard"

export default function Page() {
  return <EnhancedSupermarketDashboard />
}
